DROP INDEX "idx_pivottablewidgetdemo$salesorder_employee_pivottablewidgetdemo$employee_pivottablewidgetdemo$salesorder";
DROP INDEX "idx_pivottablewidgetdemo$incident_carrier_pivottablewidgetdemo$carrier_pivottablewidgetdemo$incident";
DROP INDEX "idx_pivottablewidgetdemo$incident_employee_pivottablewidgetdemo$employee_pivottablewidgetdemo$incident";
DROP INDEX "idx_pivottablewidgetdemo$incident_category_pivottablewidgetdemo$category_pivottablewidgetdemo$incident";
ALTER TABLE "pivottablewidgetdemo$carrier" RENAME TO "myfirstmodule$carrier";
ALTER TABLE "pivottablewidgetdemo$category" RENAME TO "myfirstmodule$category";
ALTER TABLE "pivottablewidgetdemo$employee" RENAME TO "myfirstmodule$employee";
ALTER TABLE "pivottablewidgetdemo$incident" RENAME TO "myfirstmodule$incident";
ALTER TABLE "pivottablewidgetdemo$salesorder" RENAME TO "myfirstmodule$salesorder";
ALTER TABLE "pivottablewidgetdemo$salesorder_employee" RENAME TO "myfirstmodule$salesorder_employee";
ALTER TABLE "pivottablewidgetdemo$incident_carrier" RENAME TO "myfirstmodule$incident_carrier";
ALTER TABLE "pivottablewidgetdemo$incident_employee" RENAME TO "myfirstmodule$incident_employee";
ALTER TABLE "pivottablewidgetdemo$incident_category" RENAME TO "myfirstmodule$incident_category";
ALTER SEQUENCE "pivottablewidgetdemo$carrier_number_mxseq" RENAME TO "myfirstmodule$carrier_number_mxseq";
UPDATE "mendixsystem$sequence"
 SET "name" = 'myfirstmodule$carrier_number_mxseq'
 WHERE "attribute_id" = 'cf2eeaec-0182-4660-adb7-eed9ebfa8eaa';
UPDATE "mendixsystem$entity"
 SET "entity_name" = 'MyFirstModule.Carrier', 
"table_name" = 'myfirstmodule$carrier', 
"superentity_id" = NULL
 WHERE "id" = '63430308-be40-410e-890f-29469c631516';
ALTER SEQUENCE "pivottablewidgetdemo$category_number_mxseq" RENAME TO "myfirstmodule$category_number_mxseq";
UPDATE "mendixsystem$sequence"
 SET "name" = 'myfirstmodule$category_number_mxseq'
 WHERE "attribute_id" = 'a2b57491-641a-449d-908d-873a4a2c3bea';
UPDATE "mendixsystem$entity"
 SET "entity_name" = 'MyFirstModule.Category', 
"table_name" = 'myfirstmodule$category', 
"superentity_id" = NULL
 WHERE "id" = '224f2481-ba2d-45ee-be0c-d3c09256295c';
ALTER SEQUENCE "pivottablewidgetdemo$employee_number_mxseq" RENAME TO "myfirstmodule$employee_number_mxseq";
UPDATE "mendixsystem$sequence"
 SET "name" = 'myfirstmodule$employee_number_mxseq'
 WHERE "attribute_id" = 'b078e27f-2453-440d-9b4f-4ffca4e4e118';
UPDATE "mendixsystem$entity"
 SET "entity_name" = 'MyFirstModule.Employee', 
"table_name" = 'myfirstmodule$employee', 
"superentity_id" = NULL
 WHERE "id" = '4c0d0bec-94f5-448e-89de-e4e3220c5721';
UPDATE "mendixsystem$entity"
 SET "entity_name" = 'MyFirstModule.Incident', 
"table_name" = 'myfirstmodule$incident', 
"superentity_id" = NULL
 WHERE "id" = '7175d5c6-b4dc-43fb-82d3-a95c6748aa72';
ALTER SEQUENCE "pivottablewidgetdemo$salesorder_ordernumber_mxseq" RENAME TO "myfirstmodule$salesorder_ordernumber_mxseq";
UPDATE "mendixsystem$sequence"
 SET "name" = 'myfirstmodule$salesorder_ordernumber_mxseq'
 WHERE "attribute_id" = '672010b1-9b31-4c06-9e0c-80b39827883e';
UPDATE "mendixsystem$entity"
 SET "entity_name" = 'MyFirstModule.SalesOrder', 
"table_name" = 'myfirstmodule$salesorder', 
"superentity_id" = NULL
 WHERE "id" = '17904c0e-f744-4105-b6c7-03057133696e';
ALTER TABLE "myfirstmodule$salesorder_employee" ALTER COLUMN "pivottablewidgetdemo$employeeid" RENAME TO "myfirstmodule$employeeid";
ALTER TABLE "myfirstmodule$salesorder_employee" ALTER COLUMN "pivottablewidgetdemo$salesorderid" RENAME TO "myfirstmodule$salesorderid";
CREATE INDEX "idx_myfirstmodule$salesorder_employee_myfirstmodule$employee_myfirstmodule$salesorder" ON "myfirstmodule$salesorder_employee"
	("myfirstmodule$employeeid","myfirstmodule$salesorderid");
UPDATE "mendixsystem$association"
 SET "association_name" = 'MyFirstModule.SalesOrder_Employee', 
"table_name" = 'myfirstmodule$salesorder_employee', 
"parent_entity_id" = '17904c0e-f744-4105-b6c7-03057133696e', 
"child_entity_id" = '4c0d0bec-94f5-448e-89de-e4e3220c5721', 
"parent_column_name" = 'myfirstmodule$salesorderid', 
"child_column_name" = 'myfirstmodule$employeeid', 
"index_name" = 'idx_myfirstmodule$salesorder_employee_myfirstmodule$employee_myfirstmodule$salesorder'
 WHERE "id" = '8d505bf0-3936-4964-bbfd-4203a60f0ded';
ALTER TABLE "myfirstmodule$incident_carrier" ALTER COLUMN "pivottablewidgetdemo$incidentid" RENAME TO "myfirstmodule$incidentid";
ALTER TABLE "myfirstmodule$incident_carrier" ALTER COLUMN "pivottablewidgetdemo$carrierid" RENAME TO "myfirstmodule$carrierid";
CREATE INDEX "idx_myfirstmodule$incident_carrier_myfirstmodule$carrier_myfirstmodule$incident" ON "myfirstmodule$incident_carrier"
	("myfirstmodule$carrierid","myfirstmodule$incidentid");
UPDATE "mendixsystem$association"
 SET "association_name" = 'MyFirstModule.Incident_Carrier', 
"table_name" = 'myfirstmodule$incident_carrier', 
"parent_entity_id" = '7175d5c6-b4dc-43fb-82d3-a95c6748aa72', 
"child_entity_id" = '63430308-be40-410e-890f-29469c631516', 
"parent_column_name" = 'myfirstmodule$incidentid', 
"child_column_name" = 'myfirstmodule$carrierid', 
"index_name" = 'idx_myfirstmodule$incident_carrier_myfirstmodule$carrier_myfirstmodule$incident'
 WHERE "id" = 'c510fa0a-cadf-4b6e-a6b5-9616a238f504';
ALTER TABLE "myfirstmodule$incident_employee" ALTER COLUMN "pivottablewidgetdemo$employeeid" RENAME TO "myfirstmodule$employeeid";
ALTER TABLE "myfirstmodule$incident_employee" ALTER COLUMN "pivottablewidgetdemo$incidentid" RENAME TO "myfirstmodule$incidentid";
CREATE INDEX "idx_myfirstmodule$incident_employee_myfirstmodule$employee_myfirstmodule$incident" ON "myfirstmodule$incident_employee"
	("myfirstmodule$employeeid","myfirstmodule$incidentid");
UPDATE "mendixsystem$association"
 SET "association_name" = 'MyFirstModule.Incident_Employee', 
"table_name" = 'myfirstmodule$incident_employee', 
"parent_entity_id" = '7175d5c6-b4dc-43fb-82d3-a95c6748aa72', 
"child_entity_id" = '4c0d0bec-94f5-448e-89de-e4e3220c5721', 
"parent_column_name" = 'myfirstmodule$incidentid', 
"child_column_name" = 'myfirstmodule$employeeid', 
"index_name" = 'idx_myfirstmodule$incident_employee_myfirstmodule$employee_myfirstmodule$incident'
 WHERE "id" = 'fd6e3d53-d751-4f38-9946-37dc3ce979a6';
ALTER TABLE "myfirstmodule$incident_category" ALTER COLUMN "pivottablewidgetdemo$incidentid" RENAME TO "myfirstmodule$incidentid";
ALTER TABLE "myfirstmodule$incident_category" ALTER COLUMN "pivottablewidgetdemo$categoryid" RENAME TO "myfirstmodule$categoryid";
CREATE INDEX "idx_myfirstmodule$incident_category_myfirstmodule$category_myfirstmodule$incident" ON "myfirstmodule$incident_category"
	("myfirstmodule$categoryid","myfirstmodule$incidentid");
UPDATE "mendixsystem$association"
 SET "association_name" = 'MyFirstModule.Incident_Category', 
"table_name" = 'myfirstmodule$incident_category', 
"parent_entity_id" = '7175d5c6-b4dc-43fb-82d3-a95c6748aa72', 
"child_entity_id" = '224f2481-ba2d-45ee-be0c-d3c09256295c', 
"parent_column_name" = 'myfirstmodule$incidentid', 
"child_column_name" = 'myfirstmodule$categoryid', 
"index_name" = 'idx_myfirstmodule$incident_category_myfirstmodule$category_myfirstmodule$incident'
 WHERE "id" = 'b0083b61-56c0-47f6-96fb-87312fffb6e7';
UPDATE "mendixsystem$version"
 SET "versionnumber" = '4.0.7', 
"lastsyncdate" = '20140411 08:39:47';
